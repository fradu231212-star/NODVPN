import 'dart:async';
import 'package:flutter/material.dart';
import 'package:sing_box/sing_box.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SingBox.instance.initialize(const SingBoxOptions(
    android: SingBoxAndroidOptions(
      notificationTitle: 'NOVA VPN',
      showTrafficInNotification: true,
      stopActionTitle: 'Отключить',
    ),
  ));
  runApp(const NovaApp());
}

class NovaApp extends StatelessWidget {
  const NovaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'NOVA VPN',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF030B1B),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF12A8FF), brightness: Brightness.dark),
      cardColor: const Color(0xFF0A1A35),
    ),
    home: const HomePage(),
  );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final input = TextEditingController();
  List<SingBoxServerConfig> servers = [];
  String? selectedId;
  String message = 'Добавь ссылку сервера или URL подписки';
  bool busy = false;
  SingBoxConnectionStatus status = SingBox.instance.status;
  StreamSubscription? statusSub;

  bool get active => status.isActive;

  @override
  void initState() {
    super.initState();
    statusSub = SingBox.instance.watchConnectionStatus().listen((s) {
      if (mounted) setState(() => status = s);
    });
    loadServers();
  }

  Future<void> loadServers() async {
    try {
      final list = await SingBox.instance.getServerConfigs();
      if (!mounted) return;
      setState(() {
        servers = list;
        if (servers.isNotEmpty) selectedId ??= servers.first.id;
      });
    } catch (e) { setMessage('Не удалось загрузить серверы: $e'); }
  }

  void setMessage(String value) {
    if (mounted) setState(() => message = value);
  }

  Future<void> importSource() async {
    final source = input.text.trim();
    if (source.isEmpty) { setMessage('Вставь ссылку сервера или подписки.'); return; }
    setState(() => busy = true);
    try {
      String body = source;
      if (source.startsWith('https://') || source.startsWith('http://')) {
        final response = await http.get(Uri.parse(source)).timeout(const Duration(seconds: 20));
        if (response.statusCode != 200) throw Exception('HTTP ${response.statusCode}');
        body = response.body;
      }
      final imported = await SingBox.instance.importServerConfigs(body, subscriptionId: 'nova-${DateTime.now().millisecondsSinceEpoch}');
      await loadServers();
      if (imported.isNotEmpty) {
        setState(() {
          selectedId = imported.first.id;
          input.clear();
          message = 'Добавлено серверов: ${imported.length}';
        });
      } else {
        setMessage('В источнике не найдено поддерживаемых серверов.');
      }
    } catch (e) {
      setMessage('Ошибка импорта: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> connect() async {
    if (active) {
      try { await SingBox.instance.disconnect(); setMessage('Отключено'); }
      catch (e) { setMessage('Ошибка отключения: $e'); }
      return;
    }
    if (servers.isEmpty || selectedId == null) {
      setMessage('Сначала добавь ссылку или подписку.');
      return;
    }
    setState(() => busy = true);
    try {
      await SingBox.instance.setActiveServerConfig(selectedId!);
      await SingBox.instance.connectToActiveServer();
      setMessage('Подключено');
    } on SingBoxPermissionException {
      setMessage('Разреши создание VPN-подключения в окне Android.');
    } catch (e) {
      setMessage('Не удалось подключиться: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> removeSelected() async {
    if (selectedId == null) return;
    try {
      await SingBox.instance.removeServerConfig(selectedId!);
      setState(() { servers.removeWhere((s) => s.id == selectedId); selectedId = servers.isEmpty ? null : servers.first.id; });
      setMessage('Сервер удалён');
    } catch (e) { setMessage('Ошибка удаления: $e'); }
  }

  @override
  void dispose() {
    input.dispose();
    statusSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final statusText = switch (status) {
      SingBoxConnectionStatus.connected => 'ПОДКЛЮЧЕНО',
      SingBoxConnectionStatus.connecting => 'ПОДКЛЮЧЕНИЕ…',
      SingBoxConnectionStatus.disconnecting => 'ОТКЛЮЧЕНИЕ…',
      _ => 'НЕ ПОДКЛЮЧЕНО',
    };
    return Scaffold(
      appBar: AppBar(title: const Text('NOVA VPN', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)), centerTitle: true),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
        const SizedBox(height: 12),
        const Icon(Icons.shield_rounded, size: 76, color: Color(0xFF19B5FF)),
        const Center(child: Text('NOVA VPN', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: Color(0xFF62CFFF)))),
        Center(child: Text(statusText, style: const TextStyle(color: Color(0xFF83CFFF), letterSpacing: 2))),
        const SizedBox(height: 20),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('Добавить сервер или подписку', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(controller: input, minLines: 1, maxLines: 4, decoration: const InputDecoration(
            hintText: 'vless://… или https://… (URL подписки)',
            border: OutlineInputBorder(),
          )),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: busy ? null : importSource, icon: const Icon(Icons.add_link), label: const Text('Импортировать')),
          const Text('Поддерживаются ссылки и подписки форматов VLESS, VMess, Trojan, Shadowsocks, Hysteria2, TUIC и другие форматы sing-box.', style: TextStyle(fontSize: 12, color: Colors.white60)),
        ]))),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Мои серверы', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            IconButton(onPressed: loadServers, icon: const Icon(Icons.refresh)),
          ]),
          if (servers.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('Пока нет серверов. Добавь ссылку выше.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60))),
          ...servers.map((s) => RadioListTile<String>(
            value: s.id, groupValue: selectedId, onChanged: active ? null : (v) => setState(() => selectedId = v),
            title: Text(s.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            dense: true, contentPadding: EdgeInsets.zero,
          )),
          OutlinedButton.icon(onPressed: selectedId == null || active ? null : removeSelected, icon: const Icon(Icons.delete_outline), label: const Text('Удалить выбранный сервер')),
        ]))),
        const SizedBox(height: 8),
        SizedBox(height: 56, child: FilledButton.icon(
          onPressed: busy ? null : connect,
          icon: Icon(active ? Icons.power_settings_new : Icons.bolt),
          label: Text(busy ? 'ПОДОЖДИ…' : active ? 'ОТКЛЮЧИТЬ' : 'ПОДКЛЮЧИТЬ', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
        )),
        const SizedBox(height: 12),
        Center(child: Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF8DBCEB)))),
        const SizedBox(height: 18),
        const Text('NOVA VPN — клиент. Для подключения нужна действующая ссылка/подписка от VPN-провайдера. Приложение не создаёт серверы и не выдаёт ключи само.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.white38)),
      ])),
    );
  }
}
